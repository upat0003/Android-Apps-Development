package edu.monash.fit2081.db;

public class Static {

    public static int x1;
    public static int y1;

}
