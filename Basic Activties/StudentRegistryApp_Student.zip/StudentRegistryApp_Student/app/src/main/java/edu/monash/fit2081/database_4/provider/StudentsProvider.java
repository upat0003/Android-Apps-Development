package edu.monash.fit2081.database_4.provider;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.text.TextUtils;

public class StudentsProvider extends ContentProvider {

    private static final int STUDENTS = 100;
    private static final int STUDENTS_ID = 200;
    private StudentsDbHelper mDbHelper;
    private static final UriMatcher sUriMatcher = createUriMatcher();


    // content://uthority/

    //With the help of the method below, we are matching the incoming URIs to it's type
    private static UriMatcher createUriMatcher() {

        /*
        content://monash.edu.w8/students (content//authorityName/tableName) (Here we are dealing with the entire table)
        content://moansh.edu.w8/students/89 (content/authorityName/tableName/rowNumber) (Here we are dealing with the particular row of the table)
        content://monash.edu.w8/teachers (here we are dealing with a different table)
        */

        final UriMatcher uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        final String authority = SchemeClass.CONTENT_AUTHORITY;

        //sUriMatcher will return code 100 if uri like authority/students
        uriMatcher.addURI(authority, SchemeClass.Student.PATH_VERSION, STUDENTS);

        //sUriMatcher will return code 200 if uri like e.g. authority/shapes/7 (where 7 is id of row in shapes table)
        uriMatcher.addURI(authority, SchemeClass.Student.PATH_VERSION + "/#", STUDENTS_ID);

        return uriMatcher;
    }

    @Override
    public boolean onCreate() {
        mDbHelper = new StudentsDbHelper(getContext());
        return true; //should return true if Content Provider successfully created
    }


    //*not used in this app
    @Override
    public String getType(Uri uri) {

        switch ((sUriMatcher.match(uri))) {
            case STUDENTS:
                return SchemeClass.Student.CONTENT_TYPE;
            case STUDENTS_ID:
                return SchemeClass.Student.CONTENT_ITEM_TYPE;
            default:
                throw new IllegalArgumentException("Unknown URI: " + uri);

        }
    }

    //
    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {

            // Use SQLiteQueryBuilder for querying db
            SQLiteQueryBuilder queryBuilder = new SQLiteQueryBuilder();

            queryBuilder.setTables(SchemeClass.Student.TABLE_NAME);

            // Record id
            String id;

            // Match Uri pattern
            int uriType = sUriMatcher.match(uri);

            //based on the URI type that we receive from the above, we will take an action accordingly
            switch (uriType) {

                case STUDENTS: //no trailing row id
                    //selection = null;
                    //selectionArgs = null;
                    break;
                case STUDENTS_ID: //trailing row id
                    selection = SchemeClass.Student.ID + " = ? ";
                    id = uri.getLastPathSegment();
                    selectionArgs = new String[]{id};
                    break;
                default:
                    throw new IllegalArgumentException("Unknown URI: " + uri);

            }

            SQLiteDatabase db = mDbHelper.getReadableDatabase();

            //here we are building the query
            Cursor cursor = queryBuilder.query(
                    db,
                    projection,
                    selection,
                    selectionArgs,
                    null,
                    null,
                    sortOrder
            );

            cursor.setNotificationUri(getContext().getContentResolver(), uri);


            return cursor;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {

            SQLiteDatabase db = mDbHelper.getWritableDatabase();
            int uriType = sUriMatcher.match(uri);
            long rowId;

            switch (uriType) {
                case STUDENTS: //no trailing row id
                    rowId = db.insertOrThrow(SchemeClass.Student.TABLE_NAME, null, values);
                    getContext().getContentResolver().notifyChange(uri, null); //whenever we insert the data, then we have to notify
                    return ContentUris.withAppendedId(SchemeClass.Student.CONTENT_URI, rowId);
                default: //a trailing row id is inappropriate for an insert as the db auto increments the primary key
                    throw new IllegalArgumentException("Unknown URI: " + uri);
            }

        }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {

            SQLiteDatabase db = mDbHelper.getWritableDatabase();
            int uriType = sUriMatcher.match(uri);
            int deletionCount = 0;

            switch (uriType) {
                case STUDENTS: //no trailing row id so selection may indicate more than 1 row needs to be deleted if they can be found
                    deletionCount = db.delete(SchemeClass.Student.TABLE_NAME, selection, selectionArgs);
                    break;
                case STUDENTS_ID: //trailing row id, so just one row to be deleted if it can be found
                    String id = uri.getLastPathSegment();
                    deletionCount = db.delete(
                            SchemeClass.Student.TABLE_NAME,
                            SchemeClass.Student.ID + " = " + id +
                                    (!TextUtils.isEmpty(selection) ? " AND (" + selection + ')' : ""), // append selection to query if selection is not empty
                            selectionArgs);
                    break;
                default:
                    throw new IllegalArgumentException("Unknown URI: " + uri);
            }

            getContext().getContentResolver().notifyChange(uri, null);//whenever we delete the data, then we have to notify
            return deletionCount;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        SQLiteDatabase db = mDbHelper.getWritableDatabase();
        int uriType = sUriMatcher.match(uri);
        int updateCount = 0;
        switch (uriType) {
            case STUDENTS: //no trailing row id so selection may indicate more than 1 row needs to be updated if they can be found
                updateCount = db.update(SchemeClass.Student.TABLE_NAME, values, selection, selectionArgs);
                break;
            case STUDENTS_ID: //trailing row id, so just one row to be updated if it can be found
                String id = uri.getLastPathSegment();
                updateCount = db.update(SchemeClass.Student.TABLE_NAME,
                        values,
                        SchemeClass.Student.ID + " =" + id +
                                (!TextUtils.isEmpty(selection) ? " AND (" + selection + ')' : ""), // append selection to query if selection is not empty
                        selectionArgs);
                break;
            default:
                throw new IllegalArgumentException("Unknown URI: " + uri);
        }

        getContext().getContentResolver().notifyChange(uri, null); //whenever we update the data, then we have to notify
        return updateCount;
    }
}
