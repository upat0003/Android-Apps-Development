package edu.monash.fit2081.statusapp;

public class ForecastStatus {
    String timeStamp;
    String status;
    String location;

    public ForecastStatus() {
    }

    public ForecastStatus(String timeStamp, String status, String location) {
        this.timeStamp = timeStamp;
        this.status = status;
        this.location=location;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setLocation (String location) {this.location = location;}

    public String getLocation() {
        return location;
    }
}
