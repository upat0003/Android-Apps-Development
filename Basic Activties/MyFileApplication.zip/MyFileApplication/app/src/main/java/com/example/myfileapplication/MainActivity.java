package com.example.myfileapplication;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    String TAG = "LIFE_CYCLE_ACT";
    SharedPreferences sharedPreferences;
    EditText editText1,editText2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText1=findViewById(R.id.editText1);
        editText2=findViewById(R.id.editText2);

        Log.i(TAG, "onCreate()");



    }



    public void savedFile(View v) {
        String edit_text1 = editText1.getText().toString();
        String edit_text2 = editText2.getText().toString();

        if (edit_text1.isEmpty() || edit_text2.isEmpty()) {
            return;
        }
        sharedPreferences = getSharedPreferences(edit_text1, MODE_PRIVATE);

        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString("custom_string",edit_text2);
        editor.commit();
    }

    public void loadedFile(View v){
        String edit_text1 = editText1.getText().toString();

        if (edit_text1.isEmpty()) {
            return;
        }
        sharedPreferences = getSharedPreferences(edit_text1, MODE_PRIVATE);
        String retrieved_string = sharedPreferences.getString("custom_string", "Default Value");

    }
}
