package edu.monash.fit2081.googlebooks;

import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.lang.reflect.Type;
import java.util.ArrayList;


public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder> {

    ArrayList<GoogleBook> dataItems;
    public RecyclerAdapter(ArrayList<GoogleBook> googleBook) {
        super();
        dataItems=googleBook;
    }

    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view=LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.card_layout,viewGroup,false);
        ViewHolder viewHolder=new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {

        viewHolder.authors.setText(dataItems.get(position).getAuthors());
        viewHolder.bookTitle.setText(dataItems.get(position).getBookTitle());
        viewHolder.publishedDate.setText(dataItems.get(position).getPublishedDate());

        if(position%2==1) {
            int color_primary = viewHolder.itemView.getContext().getResources().getColor(R.color.colorPrimary);
            viewHolder.itemView.setBackgroundColor(color_primary);
        }
        else{
            int color_accent = viewHolder.itemView.getContext().getResources().getColor(R.color.colorAccent);
            viewHolder.itemView.setBackgroundColor(color_accent);
        }

        final int fPosition = position+1;
        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Item at position " + fPosition + " is clicked!", Snackbar.LENGTH_LONG).setAction("Action", null).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        int size =dataItems.size();
        return size;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public View passedInView;
        public Type recyclerView;

        public View itemView;
        public TextView authors;
        public TextView bookTitle;
        public TextView publishedDate;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            this.itemView=itemView;
            authors=itemView.findViewById(R.id.author);
            bookTitle=itemView.findViewById(R.id.bookTitle);
            publishedDate=itemView.findViewById(R.id.publishedDate);

            passedInView=itemView;
            recyclerView=passedInView.findViewById(R.id.recycler_view);

        }
    }
}
