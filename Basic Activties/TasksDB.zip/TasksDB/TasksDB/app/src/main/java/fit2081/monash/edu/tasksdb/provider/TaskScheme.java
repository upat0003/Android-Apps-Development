package fit2081.monash.edu.tasksdb.provider;

public class TaskScheme {
    public static final String TABLE_NAME = "taskstable";

    //telling the database what all columns are there in my table
    public static final String ID = "_id";
    public static final String NUMBER_OF_ROOMS = "number_of_rooms";
    public static final String NUMBER_OF_GUESTS = "number_of_guests";
    public static final String TYPE_OF_ROOM = "roomTypes";
}
