package fit2081.monash.edu.tasksdb;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.ContentValues;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

import fit2081.monash.edu.tasksdb.provider.TaskScheme;
import fit2081.monash.edu.tasksdb.provider.TasksDBHelper;

public class MainActivity extends AppCompatActivity {

    TasksDBHelper db;
    ListView lvItems;
    ItemCursorAdapter itemAdaptor;
    int totalRooms;
    int totalGuest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Reference to the DB
        db = new TasksDBHelper(this, TasksDBHelper.DB_NAME, null, TasksDBHelper.DB_VERSION);
        itemAdaptor = new ItemCursorAdapter(this, null, 2, db);

        //Reference to the listview
        lvItems = findViewById(R.id.tasks_list);
        //Add a header to the listview
        lvItems.addHeaderView(View.inflate(this, R.layout.list_header, null));
        //link the adapter and the listview
        lvItems.setAdapter(itemAdaptor);
        // this function is used to fetch all the tasks from the database and provide them to the adapter.
        calculate();
        loadTasks();
    }

    private void loadTasks() {
        //Cursor is a temporary buffer area which stores results from a SQLiteDataBase query.
        Cursor cursor = db.getAllTasks();
        itemAdaptor.changeCursor(cursor);
    }

    public void addTaskBtnHandler(View view) {

        int tempRoomNo = 0;

        ContentValues contentValues = new ContentValues();

        EditText numberOfRooms = findViewById(R.id.numberOfRooms);
        EditText numberOfGuests = findViewById(R.id.numberOfGuests);
        TextView upperRooms = findViewById(R.id.roomNumberUpper);
        TextView upperGuests = findViewById(R.id.guestNumberUpper);
        Spinner typeOfRoom = findViewById(R.id.roomType);

        // save all the values of the three columns in a contentvalues object
        //ContentValues is a name value pair, used to insert or update values into database tables.
        // ContentValues object will be passed to SQLiteDataBase objects insert() and update() functions.

        String RoomNumbers = numberOfRooms.getText().toString();
        String GuestNumbers = numberOfGuests.getText().toString();
        String RoomType = typeOfRoom.getSelectedItem().toString();

        tempRoomNo = Integer.parseInt(RoomNumbers) + totalRooms;

        if (!RoomNumbers.isEmpty() && !GuestNumbers.isEmpty())

        {
            if ((tempRoomNo <= 100) && (Integer.parseInt(RoomNumbers) > 0) && (Integer.parseInt(GuestNumbers)>0) && (totalRooms != 100))

            {
                tempRoomNo = 0;
                totalRooms = totalRooms + Integer.parseInt(RoomNumbers);
                totalGuest = totalGuest + Integer.parseInt(GuestNumbers);
                upperGuests.setText(Integer.toString(totalGuest));
                upperRooms.setText(Integer.toString(totalRooms));
                contentValues.put(TaskScheme.NUMBER_OF_ROOMS, numberOfRooms.getText().toString()); //name of the column is the key and data is the value
                contentValues.put(TaskScheme.NUMBER_OF_GUESTS, numberOfGuests.getText().toString());
                contentValues.put(TaskScheme.TYPE_OF_ROOM, RoomType);
                // The implementation of addTask function can be found in TasksDBHelper
                db.addTask(contentValues);
                loadTasks(); //for refreshing the UI

            }

            else

            {
                if (tempRoomNo >= 100) {

                    Toast toast = Toast.makeText(this,"Booking rooms size already exceeds",Toast.LENGTH_LONG);
                    toast.show();
                    tempRoomNo = 0;

                }

                else if (Integer.parseInt(RoomNumbers) <= 0) {
                    Toast toast = Toast.makeText(this,"NUMBER OF ROOMS SHOULD BE GREATER THAN 0",Toast.LENGTH_LONG);
                    toast.show();
                }

                else if (Integer.parseInt(GuestNumbers) <= 0) {
                    Toast toast = Toast.makeText(this,"NUMBER OF GUESTS SHOULD BE GREATER THAN 0",Toast.LENGTH_LONG);
                    toast.show();
                }

                else {
                    Toast toast = Toast.makeText(this,"Invalid Input",Toast.LENGTH_LONG);
                    toast.show();
                }

            }

        }

        else
        {
            Toast toast = Toast.makeText(this,"Invalid Input",Toast.LENGTH_LONG);
            toast.show();
        }
    }


    public void calculate() {

        Cursor cursor = db.getAllTasks();
        int TotalNoRoom = 0;
        int TotalNoGuest = 0;

        TextView upperRooms = findViewById(R.id.roomNumberUpper);
        TextView upperGuests = findViewById(R.id.guestNumberUpper);

        while (cursor.moveToNext()) {

            TotalNoRoom += Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow(TaskScheme.NUMBER_OF_ROOMS)));
            TotalNoGuest += Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow(TaskScheme.NUMBER_OF_ROOMS)));

        }

        totalRooms = TotalNoRoom;
        totalGuest = TotalNoGuest;

        upperGuests.setText(Integer.toString(TotalNoGuest));
        upperRooms.setText(Integer.toString(TotalNoRoom));



    }

}
