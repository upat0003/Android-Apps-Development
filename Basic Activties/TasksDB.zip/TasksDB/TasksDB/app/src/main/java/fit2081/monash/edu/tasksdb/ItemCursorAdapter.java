package fit2081.monash.edu.tasksdb;

import android.content.Context;
import android.database.Cursor;
import android.support.v4.widget.CursorAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

import fit2081.monash.edu.tasksdb.provider.TaskScheme;
import fit2081.monash.edu.tasksdb.provider.TasksDBHelper;

public class ItemCursorAdapter extends CursorAdapter {
    TasksDBHelper db;
    Context activityContext;
    public ItemCursorAdapter(Context context, Cursor c, int flags, TasksDBHelper _db) {
        super(context, c, flags);
        activityContext = context;
        db=_db;
    }

    @Override
    //add data to each row
    public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
        return LayoutInflater.from(context).inflate(R.layout.list_item, viewGroup, false);
    }

    @Override
    //binds data to each row
    public void bindView(View view, Context context, Cursor cursor) {
        TextView number_of_rooms =view.findViewById(R.id.list_task_number_of_rooms);
        TextView number_of_guests =view.findViewById(R.id.list_task_number_of_guests);
        TextView type_of_room = view.findViewById(R.id.roomTypeTextView);

//        TextView Upper_Guests = view.findViewById(R.id.guestNumberUpper);
//        TextView Upper_Rooms = view.findViewById(R.id.roomNumberUpper);

        number_of_rooms.setText(cursor.getString(cursor.getColumnIndexOrThrow(TaskScheme.NUMBER_OF_ROOMS)));
        number_of_guests.setText(cursor.getString(cursor.getColumnIndexOrThrow(TaskScheme.NUMBER_OF_GUESTS)));
        type_of_room.setText(cursor.getString(cursor.getColumnIndexOrThrow(TaskScheme.TYPE_OF_ROOM)));

//        Upper_Guests.setText(cursor.getString(cursor.getColumnIndexOrThrow(TaskScheme.NUMBER_OF_GUESTS)));
//        Upper_Rooms.setText(cursor.getString(cursor.getColumnIndexOrThrow(TaskScheme.NUMBER_OF_ROOMS)));

        final String id = cursor.getString(cursor.getColumnIndexOrThrow(TaskScheme.ID));

        Button removeBtn = view.findViewById(R.id.list_delete_task);
        removeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteShape(id);
                MainActivity LocalActRef = new MainActivity();
                LocalActRef = (MainActivity)activityContext;
                LocalActRef.calculate();
            }
        });

    }

    public void deleteShape(String id) {
        db.deleteTask(Integer.parseInt(id));
        changeCursor(db.getAllTasks()); //the list of rows has been changed so this will update the list view

    }

}
