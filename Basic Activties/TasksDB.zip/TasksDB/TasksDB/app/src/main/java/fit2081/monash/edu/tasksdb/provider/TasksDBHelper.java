package fit2081.monash.edu.tasksdb.provider;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;


public class TasksDBHelper extends SQLiteOpenHelper {
    // Database name and version
    public final static String DB_NAME = "TasksDB.db";
    public final static int DB_VERSION = 5;
    Context myContext;

    //here we are creating the table
    private final static String TASKS_TABLE_CREATE =
            "CREATE TABLE " +
                    TaskScheme.TABLE_NAME + " (" +
                    TaskScheme.ID + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                    TaskScheme.NUMBER_OF_ROOMS + " INTEGER," +
                    TaskScheme.NUMBER_OF_GUESTS + " INTEGER, " +
                    TaskScheme.TYPE_OF_ROOM + " STRING); ";


    public TasksDBHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        // name : name of the database , factory : class used to create cursor
        super(context, name, factory, version);
        myContext = context;
    }

    @Override
    //if the database doesn't exist, then only this method will be called
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TASKS_TABLE_CREATE);

    }

    // db : the reference to database , i : old db version , i1 : new version
    @Override
     public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + TaskScheme.TABLE_NAME); //deleting the old table
        onCreate(db); //creating the new table
    }
    //method for entering the data in database
    public void addTask(ContentValues contentValues) {

        SQLiteDatabase db = getWritableDatabase();//getting a writable access to database in order to enter the data
        db.insert(TaskScheme.TABLE_NAME, null, contentValues);
        db.close();
    }

    public Cursor getAllTasks() {
        SQLiteDatabase db = getReadableDatabase(); //getting the readable access to database in order to enter the data
        Cursor tasks = db.rawQuery("select * from " + TaskScheme.TABLE_NAME, null);
        return tasks;
    }

    public boolean deleteTask(int taskId) {
        boolean result;
        SQLiteDatabase db = getWritableDatabase();
        String[] args = {Integer.toString(taskId)}; //getting the taskId
        result = db.delete(TaskScheme.TABLE_NAME, "_id=?", args) > 0; //args is holding the id here and db.delete will return a number
        return result;
    }
}
