package edu.monash.fit2081.callsfilter;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    TextView Landline, Mobile, Number;
    SharedPreferences sharedPreferences;
    DataReceiverBroadcast myReceiver;
    int count_Number=0, count_Landline=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Landline=findViewById(R.id.Landline);
        Mobile=findViewById(R.id.Mobile);
        Number=findViewById(R.id.Number);

        List<String> wantedPermissions = new ArrayList<>();

        wantedPermissions.add(Manifest.permission.CALL_PHONE);
        wantedPermissions.add(Manifest.permission.READ_CALL_LOG);
        wantedPermissions.add(Manifest.permission.READ_PHONE_STATE);
        wantedPermissions.add(Manifest.permission.PROCESS_OUTGOING_CALLS);


        ActivityCompat.requestPermissions(this, wantedPermissions.toArray(new String[wantedPermissions.size()]), 0);

        myReceiver=new DataReceiverBroadcast();
    }

    @Override
    protected void onResume() {
        super.onResume();

        if(myReceiver!=null){
            registerReceiver(myReceiver,new IntentFilter("intent_filter.data"));
        }
        sharedPreferences=getSharedPreferences("file_name",MODE_PRIVATE);

        String retrieved_ll = sharedPreferences.getString("Land_line", "0");
        String retrieved_mobile = sharedPreferences.getString("mobile", "0");
        String retrieved_number = sharedPreferences.getString("number", "Default Value");

        Landline.setText(retrieved_ll);
        Mobile.setText(retrieved_mobile);
        Number.setText(retrieved_number);

        count_Landline = Integer.parseInt(retrieved_ll);
        count_Number = Integer.parseInt(retrieved_mobile);

     }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(myReceiver);
        String Land_line=Landline.getText().toString();
        String mobile=Mobile.getText().toString();
        String number=Number.getText().toString();


        sharedPreferences = getSharedPreferences("file_name",MODE_PRIVATE);

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("Land_line",Land_line);
        editor.putString("mobile",mobile);
        editor.putString("number",number);

        editor.commit();


    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    class DataReceiverBroadcast extends BroadcastReceiver{
        @Override
        public void onReceive(Context context, Intent intent) {
            String incoming_number = intent.getExtras().getString("incoming_number");
            Log.i("incoming_number",incoming_number);

            Number.setText(incoming_number);

            if (incoming_number.startsWith("03")){
                count_Landline++;
            }
            else {
                count_Number++;
            }

            Landline.setText(count_Landline+"");
            Mobile.setText(count_Number+"");
        }
    }
}
