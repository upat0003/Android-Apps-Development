package edu.monash.fit2081.countryinfo;

import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class WikiActivity extends AppCompatActivity {

    WebView webpage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wiki2);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);


        final String selectedCountry = getIntent().getStringExtra("country");

        webpage = findViewById(R.id.wikiwebview);

        webpage.setWebViewClient(new MyWebViewClient());

        String url = "https://en.wikipedia.org/wiki/" + selectedCountry;
        webpage.getSettings().setJavaScriptEnabled(true);
        webpage.loadUrl(url);


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        finish();
        return true;
    }

    private class MyWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url); // load the url
            return true;
        }

    }

}
